import { createDefaultConfig } from '../repo/src/sim/config'
import { SimulationEngine } from '../repo/src/sim/engine'

// Proposed physical contract: at 0.10 m/s, a 0.10 s checkpoint cannot contain
// more than 0.010 m of travel. The arbitrary checkpoint is accepted by config.
const config = {
  ...createDefaultConfig('coverage', 'open'),
  domainMeters: 6,
  robotSpeed: 0.1 / 6,
  fixedDt: 0.25,
  durationSeconds: 1,
  checkpointSeconds: [0.1, 0.25, 1],
  targetStatus: 'absent' as const,
  sensorNoise: 0,
  stopOnNativeDeclaration: false,
}
const frame = new SimulationEngine(config).step()
console.log(JSON.stringify({
  nominalSpeedMetresPerSecond: config.robotSpeed * config.domainMeters,
  controlTickSeconds: config.fixedDt,
  checkpoint: frame.checkpoints[0.1],
  admissiblePathMetresAtCheckpoint: 0.1 * 0.1,
  actualFrameTime: frame.time,
  actualFramePathMetres: frame.metrics.pathLengthMeters,
}, null, 2))
