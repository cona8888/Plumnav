"""Run bounded Plumnav audit commands without changing tracked project files."""
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
import json
import os
import platform
import subprocess
import time

ROOT = Path(__file__).resolve().parents[1]
REPO = Path(os.environ.get("PLUMNAV_REPO", ROOT / "repo"))
COMMANDS = {
    "source-tests": ["pnpm", "test", "--maxWorkers=2"],
    "commissioning-tests": ["pnpm", "test:commissioning"],
    "production-build": ["pnpm", "build"],
    "validation-replay": ["pnpm", "validate:data"],
    "bench-calibration": ["pnpm", "--silent", "sensor:calibrate"],
    "fitting-standard": ["pnpm", "--silent", "survey:validate", str(ROOT / "results" / "fitting-standard")],
    "fitting-challenge": ["pnpm", "--silent", "survey:validate", "--challenge", str(ROOT / "results" / "fitting-challenge")],
}

def run(name):
    command = COMMANDS[name]
    start = time.monotonic()
    log_path = ROOT / "logs" / f"{name}.log"
    try:
        with log_path.open("w") as log:
            result = subprocess.run(command, cwd=REPO, stdout=log,
                                    stderr=subprocess.STDOUT, timeout=240)
        returncode = result.returncode
    except subprocess.TimeoutExpired:
        returncode = "timeout_240_seconds"
    item = {"command": command, "cwd": str(REPO), "returncode": returncode,
            "wall_seconds": time.monotonic() - start, "log": str(log_path),
            "note": "Some independent checks ran concurrently; timings are audit runtimes, not performance benchmarks."}
    (ROOT / "results" / f"{name}.json").write_text(json.dumps(item, indent=2) + "\n")
    return {**item, "output_tail": log_path.read_text()[-2600:]}

if __name__ == "__main__":
    import sys
    names = sys.argv[1:] or list(COMMANDS)
    with ThreadPoolExecutor(max_workers=3) as executor:
        futures = {executor.submit(run, name): name for name in names}
        for future in as_completed(futures):
            print(json.dumps({"check": futures[future], **future.result()}), flush=True)
