"""Render the complete audit report. This script does not edit the repository."""
from pathlib import Path
import re
import html
from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import mm
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image, Preformatted, KeepTogether
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfbase import pdfmetrics

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'Plumnav_Pstack_Review_2026-11-03.txt'
OUT = ROOT / 'Plumnav_Pstack_Review_2026-11-03.pdf'
fontdir = Path('/usr/share/fonts/truetype/liberation2')
if (fontdir / 'LiberationSans-Regular.ttf').exists():
    for suffix, file in [('', 'LiberationSans-Regular.ttf'), ('-Bold','LiberationSans-Bold.ttf'), ('-Italic','LiberationSans-Italic.ttf')]:
        pdfmetrics.registerFont(TTFont('AuditSans'+suffix,str(fontdir/file)))
    pdfmetrics.registerFontFamily('AuditSans',normal='AuditSans',bold='AuditSans-Bold',italic='AuditSans-Italic',boldItalic='AuditSans-Bold')
    FONT='AuditSans'
else:
    FONT='Helvetica'

styles=getSampleStyleSheet()
styles.add(ParagraphStyle(name='AuditTitle',fontName=FONT+'-Bold',fontSize=22,leading=26,spaceAfter=11))
styles.add(ParagraphStyle(name='AuditH2',fontName=FONT+'-Bold',fontSize=14,leading=18,spaceBefore=15,spaceAfter=7,keepWithNext=True))
styles.add(ParagraphStyle(name='AuditH3',fontName=FONT+'-Bold',fontSize=11.5,leading=15,spaceBefore=11,spaceAfter=6,keepWithNext=True))
styles.add(ParagraphStyle(name='AuditBody',fontName=FONT,fontSize=10,leading=14,spaceAfter=7,allowWidows=0,allowOrphans=0))
styles.add(ParagraphStyle(name='AuditCell',fontName=FONT,fontSize=8.7,leading=11.8,spaceAfter=0))
styles.add(ParagraphStyle(name='AuditHeader',fontName=FONT+'-Bold',fontSize=8.7,leading=11.8,spaceAfter=0))
styles.add(ParagraphStyle(name='AuditCode',fontName='Courier',fontSize=7.8,leading=10.8,spaceBefore=6,spaceAfter=9,backColor=colors.HexColor('#f4f4f4'),borderPadding=7))
styles.add(ParagraphStyle(name='AuditCaption',fontName=FONT,fontSize=8.6,leading=11.7,spaceAfter=9,textColor=colors.HexColor('#333333')))

def inline(text):
    text=html.escape(text)
    text=re.sub(r'\[([^\]]+)\]\((https?://[^)]+)\)',r'<link href="\2" color="#202020"><u>\1</u></link>',text)
    text=re.sub(r'\*\*([^*]+)\*\*',r'<b>\1</b>',text)
    text=re.sub(r'`([^`]+)`',r'<font name="Courier">\1</font>',text)
    return text

width=A4[0]-36*mm
def make_table(lines):
    data=[]
    for line in lines:
        cells=[x.strip() for x in line.strip().strip('|').split('|')]
        if all(re.match(r'^:?-+:?$',x) for x in cells): continue
        data.append(cells)
    n=len(data[0]); head=data[0][0]
    ratios={2:[.31,.69],3:[.27,.35,.38],4:[.18,.25,.27,.30]}.get(n,[1/n]*n)
    if head=='Check':ratios=[.29,.56,.15]
    if head=='Candidate claim':ratios=[.31,.18,.51]
    if head=='Reviewer':ratios=[.23,.45,.32]
    if head=='Stage':ratios=[.16,.37,.47]
    if head=='Grid resolution':ratios=[.28,.36,.36]
    rows=[[Paragraph(inline(x),styles['AuditHeader' if r==0 else 'AuditCell']) for x in row] for r,row in enumerate(data)]
    t=Table(rows,colWidths=[width*x for x in ratios],repeatRows=1,hAlign='LEFT')
    t.setStyle(TableStyle([
      ('BACKGROUND',(0,0),(-1,0),colors.HexColor('#e8e8e8')),
      ('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,colors.HexColor('#f7f7f7')]),
      ('VALIGN',(0,0),(-1,-1),'TOP'),
      ('LEFTPADDING',(0,0),(-1,-1),7),('RIGHTPADDING',(0,0),(-1,-1),7),
      ('TOPPADDING',(0,0),(-1,-1),6),('BOTTOMPADDING',(0,0),(-1,-1),6),
      ('LINEBELOW',(0,0),(-1,0),.6,colors.black),
      ('LINEBELOW',(0,-1),(-1,-1),.35,colors.HexColor('#999999')),
    ]))
    return [KeepTogether([t,Spacer(1,7)])] if len(data)<=6 else [t,Spacer(1,7)]

lines=SOURCE.read_text().splitlines(); story=[]; i=0
while i<len(lines):
    line=lines[i].strip()
    if not line:i+=1;continue
    if line.startswith('```'):
        block=[];i+=1
        while i<len(lines) and not lines[i].startswith('```'):
            block.append(lines[i]);i+=1
        story.append(Preformatted('\n'.join(block),styles['AuditCode'],maxLineLength=93));i+=1;continue
    if line.startswith('|'):
        block=[]
        while i<len(lines) and lines[i].strip().startswith('|'):
            block.append(lines[i]);i+=1
        story.extend(make_table(block));continue
    if line.startswith('[FIGURE: '):
        path=ROOT/line[9:-1]
        if not path.exists():raise FileNotFoundError(path)
        image=Image(str(path));image.drawHeight=width*image.imageHeight/image.imageWidth;image.drawWidth=width
        story.append(image);story.append(Spacer(1,5));i+=1;continue
    if line.startswith('# '):story.append(Paragraph(inline(line[2:]),styles['AuditTitle']));i+=1;continue
    if line.startswith('## '):story.append(Paragraph(inline(line[3:]),styles['AuditH2']));i+=1;continue
    if line.startswith('### '):story.append(Paragraph(inline(line[4:]),styles['AuditH3']));i+=1;continue
    para=[line];i+=1
    while i<len(lines) and lines[i].strip() and not lines[i].startswith(('#','|','```','[FIGURE: ')):
        para.append(lines[i].strip());i+=1
    text=' '.join(para)
    story.append(Paragraph(inline(text),styles['AuditCaption' if text.startswith('Figure 1.') else 'AuditBody']))

def page(canvas,doc):
    canvas.saveState()
    canvas.setStrokeColor(colors.HexColor('#777777'));canvas.setLineWidth(.4)
    canvas.line(18*mm,A4[1]-13*mm,A4[0]-18*mm,A4[1]-13*mm)
    canvas.setFont(FONT,7.6);canvas.setFillColor(colors.HexColor('#555555'))
    canvas.drawString(18*mm,A4[1]-10.2*mm,'PLUMNAV  |  ENGINEERING REVIEW  |  3507527')
    canvas.drawString(18*mm,11*mm,'3 November 2026  |  Review only  |  Evidence and limitations retained')
    canvas.drawRightString(A4[0]-18*mm,11*mm,str(doc.page))
    canvas.restoreState()

doc=SimpleDocTemplate(str(OUT),pagesize=A4,leftMargin=18*mm,rightMargin=18*mm,topMargin=19*mm,bottomMargin=18*mm,
    title='Plumnav: evidence-based engineering review',author='ChatGPT engineering review',subject='Review-only audit of Plumnav commit 3507527')
doc.build(story,onFirstPage=page,onLaterPages=page)
print(OUT)
