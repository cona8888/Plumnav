import { createDefaultConfig } from '../../repo/src/sim/config'
import { SimulationEngine } from '../../repo/src/sim/engine'
import type { AlgorithmId } from '../../repo/src/sim/types'
import { evaluateArchivedLeakRun } from '../../repo/src/sim/researchEvaluation'

// Proposed criteria registered before execution: reported checkpoint path and elapsed
// time must describe the same physical time; valid normal configurations must complete
// with finite states; noise-free absent-source controls must not declare a source.
const results: any = { checkpoints: [], controlRuns: [], oracleBoundary: null }
for (const checkpoint of [0.05, 0.1, 0.15, 0.2]) {
 const c = { ...createDefaultConfig('coverage','open'), fixedDt:0.2, durationSeconds:1,
 checkpointSeconds:[checkpoint,1], stopOnNativeDeclaration:false, sensorNoise:0, targetStatus:'absent' as const }
 const e = new SimulationEngine(c)
 const f = e.step()
 const m = f.checkpoints[checkpoint]!
 results.checkpoints.push({checkpointSeconds:checkpoint, fixedDt:c.fixedDt,
  recordedElapsedSeconds:m.elapsedSeconds, recordedPathMeters:m.pathLengthMeters,
  maximumFeasiblePathMeters:c.robotSpeed*c.domainMeters*checkpoint,
  actualFrameTime:f.time, actualFramePathMeters:f.metrics.pathLengthMeters,
  withinNominalSpeedBound:m.pathLengthMeters<=c.robotSpeed*c.domainMeters*checkpoint+1e-9})
}
for (const method of ['coverage','surge-cast','zigzag-spiral','infotaxis','smc-kl','pmfs'] as AlgorithmId[]) {
 for (const targetStatus of ['absent','zero-emission','emitting'] as const) {
  const c={...createDefaultConfig(method,'open'), durationSeconds:20.05, checkpointSeconds:[20.05],
   seed:91371, sourceSeed:8111, controllerSeed:1021, observationModelSeed:455,
   sensorNoise:0, windNoise:0, targetStatus, stopOnNativeDeclaration:true}
  const start=performance.now()
  try {
    const e=new SimulationEngine(c), f=e.runToCompletion()
    const m=f.metrics
    results.controlRuns.push({method,targetStatus,completed:f.completed, elapsedSeconds:m.elapsedSeconds,
     nativeDeclaration:m.nativeDeclaration,terminalOutcome:m.terminalOutcome,
     conservativeOutcome:evaluateArchivedLeakRun(c,m,f.scenario.source).outcome,
     pathMeters:m.pathLengthMeters,blockedMotionTicks:m.collisionAttempts,samples:f.observations.length,
     finiteMeasurements:f.observations.every(o=>[o.concentration,o.time,o.position.x,o.position.y].every(Number.isFinite)),
     wallSeconds:(performance.now()-start)/1000})
  } catch(e) {results.controlRuns.push({method,targetStatus,error:String(e),wallSeconds:(performance.now()-start)/1000})}
 }
}
const c=createDefaultConfig('infotaxis','obstructed')
const a=new SimulationEngine({...c,sourceSeed:211}),b=new SimulationEngine({...c,sourceSeed:212})
results.oracleBoundary={differentHiddenSources:JSON.stringify(a.scenario.source)!==JSON.stringify(b.scenario.source),
 publicScenariosEqual:JSON.stringify(a.environment.scenario)===JSON.stringify(b.environment.scenario),
 privateFieldsExcluded:['source','targetStatus','seed','sourceSeed'].every(k=>!(k in a.environment.scenario)),
 sourceBlindRateEqual:a.environment.expectedHitRate({x:.3,y:.3},{x:.5,y:.5},2)===b.environment.expectedHitRate({x:.3,y:.3},{x:.5,y:.5},2)}
console.log(JSON.stringify(results,null,2))
