import { createDefaultConfig, validateSimulationConfig } from '../../repo/src/sim/config'
import { SimulationEngine } from '../../repo/src/sim/engine'
import { runBatch } from '../../repo/src/sim/batch'
const c={...createDefaultConfig('coverage','open'),durationSeconds:1,checkpointSeconds:[0,1,2]}
validateSimulationConfig(c)
const f=new SimulationEngine(c).runToCompletion()
const batch=await runBatch(c,['coverage'],['open'],1)
console.log(JSON.stringify({accepted:true,requestedCheckpoints:c.checkpointSeconds,
 retainedCheckpoints:Object.keys(f.checkpoints).map(Number),batchCheckpoints:batch.results.map(r=>r.checkpointSeconds)},null,2))
