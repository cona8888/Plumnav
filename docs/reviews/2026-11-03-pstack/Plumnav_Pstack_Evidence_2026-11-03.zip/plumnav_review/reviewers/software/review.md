# Independent software and mission-integrity review

## Scope and reviewer

Reviewer role: software correctness and mission integrity. Session-provided model identity: GPT-6 Astra Pro, inherited from parent with no model override. No independent model-family comparison is claimed. I did not see the other reviewers' conclusions before forming this report.

Snapshot: `3507527250400d25081f3793191084c9c3356a56`, `validate/controlled-release`. Verified merge base against the reported remote main SHA: `452d285e3ca6c8cfd6209bfbfe035e7ce0496fe7`. Working tree was clean at initial inspection. All my scripts/output are outside the repository under `reviewers/software`. No source, tests, data or expected results were edited.

Read implementation in `engine.ts`, `environment.ts`, `config.ts`, `controllerObservationModel.ts`, `types.ts`, the reactive, Infotaxis, SMC, PMFS and fitting-inspection controllers, `confirmation.ts`, `baseline.ts`, `curtainBearing.ts`, `researchEvaluation.ts`, replay helpers, `robot-field-replay.ts`, `validate-fitting-survey.ts`, batch and research UI aggregation paths. Reviewed relevant tests, README descriptions and repository scope. This is a focused review, not a claim of inspecting all 1,054 tracked files. Root handles overall tests, build and packaged replay.

## Verdict

The inspected implementation supports a deterministic simulation/replay workbench. The recent fitting workflow deliberately returns a follow-up nomination and abstains from source declaration. The engine separates source truth and target-presence truth from the public controller environment; a direct counterfactual check supports that boundary. The short source-absent controls behaved conservatively at the controller level. I reproduced one concrete timing/metric defect, and identified an output-semantics concern that should not be confused with source-coordinate leakage.

## Complete mission trace

1. `scripts/validate-fitting-survey.ts` constructs mapped fitting locations and a calibrated SI configuration from `createDefaultConfig`, `withCalibratedSIInlet` and the fixed halfspace reference. Hidden source positions are stored in simulation configuration; mapped fittings are public prior information.
2. `SimulationEngine` validates/deep-copies configuration, creates a scenario, chooses physical halfspace/grid/filament plume, and builds an independent controller observation model after removing `source` and `targetStatus`.
3. `createEnvironment` removes those fields again and freezes the public scenario/map. Candidate likelihoods use the separately seeded reduced observation model, not the real plume. Public transport coefficients and map are assumptions; they are not measured source coordinates.
4. `senseLocalInlets` evaluates concentration at four body-oriented offsets, advances each inlet's dynamic response, applies noise/clipping and readout cadence, and supplies validity/saturation information and noisy local wind. Legacy sensing follows a different, explicitly simplified path.
5. `AssetInspectionController.step` travels to ordered public fittings, settles, samples, compares two passes, and optionally samples an upwind/crosswind/revisit bracket. It returns a nominated fitting only as reinspection, with `nativeAbstained=true` and no source declaration.
6. Engine movement bounds SI turn rate, holds position while turning, clamps speed, checks swept motion in short probes and accumulates travelled length. Local physical mode has perfect pose and a known obstacle map; no hardware integration is established by this path.
7. Native declarations and abstentions are separately latched; fixed-budget runs freeze movement/assimilation after the terminal decision. Deadline truncation was correct for the off-grid final time tested.
8. Script records separate nominal fitting flags and conservative active-leak scores, plus observations, visits, controls and mission rows. The older engine terminal-outcome labels remain different from the conservative research evaluator; see below.

## Confirmed defect SW-1: off-grid checkpoints report future path state under an earlier time

Severity: P2 (material correctness of time-resolved diagnostics under supported custom checkpoint choices). Evidence: **reproduced against the real engine**, not a substituted controller. The same mechanism exists at the comparison base, so this is an inherited issue, not attributed to the newest changes.

Locations: `src/sim/engine.ts`, `advanceClock`, lines 953–956; `getMetrics`, lines 986 onward; `src/sim/config.ts`, lines 343–348; related batch omission at `src/sim/batch.ts`, lines 116–119.

Trigger: a requested checkpoint lies between control/motion ticks. Configuration validation accepts any finite nonnegative checkpoint. `step` first moves the robot for a full tick. `advanceClock` then detects all crossed checkpoints and calls `getMetrics(checkpoint)`. The argument changes the reported elapsed time but does not reconstruct path length or other accumulators at that earlier instant.

Expected: either compute and retain actual state at the checkpoint time, report the effective sampled time honestly, or reject unsupported off-grid checkpoint schedules.

Observed with ordinary coverage, a 100 m domain, normalized speed 0.05/s (5 m/s), `fixedDt=0.2 s`, deadline 1 s, noise-free source-absent configuration:

| Requested/reported time (s) | Recorded path (m) | Maximum physically possible path at that time (m) | Actual frame time (s) |
| --- | --- | --- | --- |
| 0.05 | 1.0000000000000053 | 0.25 | 0.2 |
| 0.10 | 1.0000000000000053 | 0.50 | 0.2 |
| 0.15 | 1.0000000000000053 | 0.75 | 0.2 |
| 0.20 | 1.0000000000000053 | 1.00 | 0.2 |

The aligned control passes with numerical tolerance. The first requested checkpoint reports four times the possible travelled distance. This can bias path-versus-time comparisons and cost accumulators. I did not establish that existing standard 30/60/120/180 s archived comparisons are affected; their control steps are aligned.

Related accepted-but-unrecorded schedule: `durationSeconds=1`, `checkpointSeconds=[0,1,2]` validates successfully, but engine and `runBatch` retain only checkpoint 1. A t=0 checkpoint can never satisfy `previousTime < checkpoint`; a post-deadline checkpoint is unreachable. The batch silently skips missing checkpoints. This is grouped with SW-1 as one checkpoint contract problem, not counted as a separate defect.

Reproduce from the snapshot repository:

```sh
node node_modules/vite-node/vite-node.mjs ../reviewers/software/probes.ts
node node_modules/vite-node/vite-node.mjs ../reviewers/software/checkpoint-range.ts
```

Stored output: `reviewers/software/probes.json` and `reviewers/software/checkpoint-range.json`.

Smallest useful remedy: if arbitrary checkpoint timing is not required, enforce a documented valid schedule in config (strictly positive, unique, no later than deadline, aligned with a sensor/control tick within tolerance, with explicit final-deadline handling). Otherwise split motion/cost integration at each requested checkpoint or retain an appropriately interpolated metric state; do not simply relabel a future snapshot. Add a regression asserting `pathLength <= speed * elapsed` in a flat fixed-speed reference, and require the requested checkpoint set to match exported rows exactly. Keep the final off-grid deadline test, which passed here.

## Concern SW-C1: ordinary batch output uses a different meaning of rejection than the conservative evaluator

Evidence: **reproduced semantic discrepancy**, not evidence of leaked source truth into a policy. For 20.05 s absent-source, zero-noise missions, Surge–Cast, Zigzag–Spiral, Infotaxis, SMC/KL and PMFS all finish without declaring. The ordinary engine emits `terminalOutcome=correct-rejection-at-deadline`; the conservative `evaluateArchivedLeakRun` returns `unresolved-deadline` for the same mission. Coverage returns `unresolved-survey` in the ordinary engine. Native declarations were false for every one of these runs.

Locations: `engine.ts` lines 1022–1040 and 1086–1092; `researchEvaluation.ts` conservative no-leak evidence contract and adapter; `batch.ts` summary aggregation; `ResearchPanel.tsx` line 260 displays a percentage labelled “correct rejection.”

A specificity-style offline metric (“no false declaration on a source-absent trial”) is legitimate. It does not prove the robot has enough observations to certify absence. The README and panel define some of these metrics, so I do not classify every use of “correct rejection” as an undisclosed oracle or a new runtime defect. The user-facing interpretation should nevertheless be aligned: either label the older metric “no declaration in absent-source trials,” or use the conservative outcomes in claim-facing results. A one-position, very short absent run should remain unresolved for operational absence confirmation.

## Executed targeted checks

Acceptance criteria were written into the external script before execution: checkpoint time/path consistency; finite completed states; exact off-grid deadline handling; no source declaration in noise-free absent controls. These are proposed review checks, not a claim about a pre-registered scientific campaign.

- Four first-step checkpoint probes at 0.05/0.1/0.15/0.2 s with 0.2 s timestep: three fail time/path consistency; aligned control passes.
- Eighteen complete 20.05 s missions: six methods (`coverage`, `surge-cast`, `zigzag-spiral`, `infotaxis`, `smc-kl`, `pmfs`) × three target states (`absent`, `zero-emission`, `emitting`). All completed with finite observations and exact final clock 20.05 s. All had 81 valid observations and zero blocked motion ticks. No source declarations in any of the eighteen runs. This is a short integrity pilot, not evidence of source-localisation efficacy; the emitting cases all remained unresolved. One scenario seed was used per method/target state and uncertainty across missions was not estimated.
- Six absent-source controller controls: 0/6 declarations; six inactive-source controls: 0/6 declarations. Do not treat those tiny denominators as a low false-declaration probability estimate.
- Source-seed counterfactual: hidden source positions differ for source seeds 211 and 212 while public environment scenarios and an evaluated candidate hit rate remain equal; private fields `source`, `targetStatus`, `seed`, `sourceSeed` are absent from public scenario. This is a concrete positive boundary check, not a proof against all possible information paths.
- Out-of-range checkpoint schedule probe: accepted request `[0,1,2]` with deadline 1 produced only `[1]` in both engine and batch results.

Shared environment: Node 24.22.1. Root installed lockfile dependencies. Per-mission wall-clock times are retained in `probes.json`; they were measured in a shared review environment and must not be used as a speed benchmark. No hardware or external paid compute was used.

## Rejected allegations / scope limits

- “The navigation policy receives true source coordinates”: rejected for inspected boundaries and checked counterfactual. The evaluator has truth by design.
- “Fitting flags are autonomous source confirmations”: rejected. The class comment, terminal abstention, script invariant and separate nomination outputs explicitly prevent this interpretation.
- “The measured-track replay validates alternative navigation”: rejected as an interpretation. Replay deliberately bypasses sensing/motion and discards proposed actions; it validates observation processing/estimation on supplied paths.
- “All zero-emission errors are invalid source leak scores”: rejected as an unqualified allegation. Legacy geometric-source-reference metrics are explicitly described, and the conservative active-leak adapter separately accounts for no emission. Claims must use the appropriate endpoint.
- “The simulator and inverse model are identical or share a true concentration oracle”: rejected for inspected implementation. There is a separately versioned and seeded reduced observation model. Shared chosen transport parameters still limit external validity.
- “A full source-localisation benchmark passed”: not claimed. These short checks establish state/clock/negative-control integrity only; the source-present controls remained unresolved.

I did not execute all research scripts, field replays, hardware interfaces, or complete multiple-condition localisation studies. Root handles broader packaged verification and other reviewers handle physical assumptions and experimental evidence.
