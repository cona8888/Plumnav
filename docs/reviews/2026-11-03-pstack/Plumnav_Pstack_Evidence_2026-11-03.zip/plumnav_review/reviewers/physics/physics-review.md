# Independent physics and robotics review

Snapshot: `3507527250400d25081f3793191084c9c3356a56`, `validate/controlled-release`.
Comparison base supplied and consistent with local history: `452d285e3ca6c8cfd6209bfbfe035e7ce0496fe7`.
Mode: REVIEW_ONLY. No tracked project file was edited. Scripts and outputs below are external review artifacts.
Reviewer: `/root/physics_review`; inherited session model, identified by the session as GPT-6 Astra Pro, with no model override. This was an independent agent pass, not a different model-family experiment. Exact serving/build metadata was not exposed.

## Verdict

The new SI half-space and delayed local-inlet implementation is internally consistent in the bounded analytical checks performed here. Its units and principal response equations withstand independent arithmetic and quadrature checks. This supports numerical verification of a deliberately restricted forward/sensor model. It does not establish a field-calibrated plume, a physical four-channel backpack, or autonomous robot deployment. The repository documentation largely makes those distinctions explicitly.

Two problems were executed: a material mass-balance failure in the older grid backend at an impermeable wall, and acceptance of an invalid physical robot starting footprint by generic SI controllers. Neither failure was seen in the standard fitting-survey configuration. Both should be corrected or explicitly bounded before extending quantitative claims to new conditions.

## Scope and inspected files

Read the attached pstack instructions, `REPOSITORY_SCOPE.md`, relevant README physics/limitations sections, `docs/inlet-calibration.md`, `docs/fitting-survey.md`, `docs/field-records.md`, and portions of field-replay documentation. Inspected `halfspaceTransport.ts`, `physicalAtmosphere.ts`, `localInletSampling.ts`, `physicalDesign.ts`, `environment.ts`, `controllerObservationModel.ts`, `scenarios.ts`, `config.ts`, engine constructor/sensing/motion/stopping interfaces, `gridPlume.ts`, `plume.ts`, `curtainBearing.ts`, `sensorProfiles.ts`, `algorithms/assetInspection.ts`, `scripts/validate-fitting-survey.ts`, calibration implementation/reference integrator, and associated relevant tests. This was not a complete line-by-line audit of every historical research algorithm or data archive.

## Confirmed finding P1: no-through-wall grid transport has a large unaccounted scalar-mass sink

**Severity:** medium quantitative-use limitation for the stated normalized demonstrator; high consequence if this backend is used as a conservative obstacle-transport reference. **Evidence:** reproduced nonconservation against the real `GridPlume` class in the prescribed-flow fixture below, not a demonstrated mass error in every default world.

**Trigger.** A unit-square field has a source at `(0.25,0.5)`, uniform flow `(0.065,0)` normalized units/s, zero diffusion/intermittency, negligible loss (`decaySeconds=1e9`), and a full-height solid wall spanning x=0.45–0.55. Source amplitude is deliberately small (`sourceRate=0.01`); the concentration never reaches 0.007, so saturation/clipping cannot explain the loss. The custom scenario follows the same interface and open-flow-plus-wall pattern used by the existing `gridPlume.test.ts` wall test.

**Important qualification.** This accepted prescribed velocity points normally into the wall; it is not a self-consistent incompressible wall flow. The fixture tests the scalar solver's advertised no-through-flow treatment under its accepted inputs. A conservative implementation must account for arriving mass, prescribe a compatible wall velocity/flux, or reject an incompatible setup. It does not show that a particular default obstacle world loses the same fraction, and it says nothing adverse about the separate SI half-space backend. The class's global no-flux documentation specifically applies to diffusion; the stronger no-through-flow language for advection appears in its local implementation comment.

**Expected.** With no wall outlet, no significant decay, and no explicit sink, area-integrated scalar mass should equal initial mass plus the measured injection budget. Proposed review tolerance: <1% relative residual at 6 s. An otherwise identical open control distinguishes wall loss from distant boundary/numerical effects. This is a normalized scalar conservation check, not a request to calibrate its mass to kg or solve Navier–Stokes.

**Observed.**

| Grid | Open relative balance error | Walled relative balance error |
|---|---:|---:|
| 32² | −0.008724% | −49.7472% |
| 64² | −0.0000211% | −47.6195% |
| 128² | +0.0000447% | −48.5814% |

At 128², expected mass is `8.6599061886e-5`, observed walled mass is `4.4528044548e-5` in normalized concentration×area units. Refinement does not remove the discrepancy.

**Code.** `src/sim/gridPlume.ts:293–313` backtraces and writes fluid destinations only; blocked destination cells are skipped. Its retain-current-value rule applies when the backtrace crosses a solid, but there is no flux balance for transport arriving at a solid face. `317–353` implements diffusion/source/loss; clipping is explicit at 353. `222–225` supplies the displayed/integrated mass. The class documentation at 50–56 promises no-flux solid handling for diffusion and the advection comment at 308–309 calls the obstacle treatment no-through-flow. Existing obstacle tests establish reduced concentration behind a wall, not conservation of scalar arriving at it.

**Smallest useful remedy.** If preserving quantitative grid transport, use conservative face fluxes with a consistent no-normal-flow wall velocity and account for boundary/source/loss terms, or reject incompatible flow inputs. If the backend remains a visual/algorithmic proxy, state its nonconservative obstacle limitation and avoid using its `totalMassAt` as physical conservation evidence. Add this balance fixture at multiple grids and also test a prescribed admissible flow field. Do not claim this is fixed by reducing the controller timestep.

**Reproduction.** From the review checkout: `node node_modules/vite-node/vite-node.mjs ../reviewers/physics/grid-mass-check.ts`. Script: `reviewers/physics/grid-mass-check.ts`; output: `reviewers/physics/grid-mass-check.json`. This finding applies to the grid backend, not the half-space backend used by the recent fitting-survey study.

## Confirmed finding P2: generic SI controller accepts an impossible starting footprint

**Severity:** medium configuration/mission-integrity defect. **Evidence:** reproduced.

**Trigger.** Build the documented SI design for Surge–Cast on a 6 m domain with a `(0.70 m × 0.31 m)` robot and `robotStartPositionOverride={x:0.02,y:0.5}`. The center is 0.12 m from the domain edge, while the engine's physical clearance radius is approximately 0.383 m. The input point is inside the unit square, but the physical robot is not.

**Expected.** Reject before starting, using the same physical clearance predicate used for every proposed motion. Proposed review criterion: any start that `environment.isBlocked` declares blocked must be rejected as a setup failure, rather than silently entering the mission statistics.

**Observed.** Construction succeeds. `engine.environment.isBlocked(engine.scenario.robotStart)` is `true`. A 5 s mission produces zero path length, 20 blocked-motion attempts, unchanged position, and `Fixed research time budget reached`.

**Code.** `config.ts:114–124,163–164` checks only that an override is finite and lies in [0,1]². `scenarios.ts:120–133` rejects a point inside an obstacle, but does not check the full robot footprint. `engine.ts:212` uses the physical circumradius for environment clearance; `engine.ts:967–978` rejects every motion probe still within it. `algorithms/assetInspection.ts:42–44` already guards its start, so the defect is confined to controllers lacking that extra check. The standard fitted asset survey is protected.

**Smallest useful remedy.** Add a common post-environment/pre-controller start-clearance validation in the engine, then test an edge start, an obstacle-adjacent start, and a valid start for all controller types. Preserve setup errors separately from algorithm timeouts in batch records.

**Reproduction.** `node node_modules/vite-node/vite-node.mjs ../reviewers/physics/physics-checks.ts`. The `boundary` object in `physics-checks.json` records the actual outcome.

## Positive checks actually run

All checks below use production modules; proposed thresholds were written in the scripts before first execution. Wall-clock duration for the combined physics-checks script's calculation was 0.115 s on Node v24.22.1; this is not a benchmark claim. Root records host hardware and common dependencies.

| Check | Observed | Criterion | Result |
|---|---:|---:|---|
| Half-space pulse mass, independent 80³ midpoint spatial integral over >8σ support | relative error 4.4642e-13 | <1e-5 | pass |
| Continuous 300 s release concentration, production Gaussian panel quadrature versus independently written 20,000-panel Simpson quadrature | relative error 2.7967e-12 | <1e-5 | pass |
| x/y/z gradients versus central finite differences | maximum relative error 1.0190e-9 | <1e-5 | pass |
| Reflecting ground derivative | exactly zero at z=0 in examined case | zero | pass |
| Ideal tube delay + first-order response + trailing average versus closed-form delayed unit step | maximum absolute error 1.7764e-15 | <1e-12 | pass |

The continuous reference settings are source height 0.025 m, source width 0.15 m, wind 0.02 m/s, diffusivity 0.001 m²/s, release rate 2e-9 kg/s, at time 300 s and sample point `(0.4,0.08,0.05)` m. The tested concentration is `4.64304580637e-7 kg/m³`. The inlet step has 1.75 s rise time constant, 3.5 s recovery constant, 0.753982 s tube transit, 1 s averaging, and a rising step at 5 s; this specific closed-form check covers rise, not a separate recovery experiment. Existing independent RK4 calibration tests cover broader manufactured pulses; root is rerunning those.

## Physics and observation contract

The SI witness integrates Gaussian releases with variance σ²+2Da and a reflecting z=0 image. Its dimensions are `(kg/s)·s/m³ = kg/m³`. Source and wind positions are converted from normalized x/y to metres by the domain length, while time stays in seconds. A fixed-height plane at the inlet height is queried from a 3D kernel, so the robot is 2D without pretending that transport spreads only in 2D. The ideal-gas methane conversion uses pressure, temperature and molecular mass. This is an internally consistent prescribed forward model.

It assumes constant horizontal flow, scalar isotropic diffusivity, finite Gaussian source width, a flat reflecting ground and no obstacle effects. A 50% duty-cycle release is implemented; arbitrary duty fractions are intentionally rejected. Zero/absent release is distinguished from a nonzero background. The SI guard rejects conflicting legacy forcing and unit contracts. It cannot establish outdoor intermittent wakes, dense-gas effects, spatially varying source fluxes, porous-media leakage or source strength estimation.

The local inlet computes volume/actual volumetric flow for an ideal plug delay; integrates a separate first-order rise/recovery state; and applies a trailing average. It samples each body-frame inlet at its current world position, publishes at an integer-tick sensor cadence, and attaches clipping flags per channel. Noise is added to readouts. Flow is per channel, not divided from an assumed shared pump. Temperature/humidity, adsorption, tube dispersion, flow variation, cross-sensitivity and cross-channel mismatch are excluded and are explicitly named as bench-calibration requirements in the documentation. The four-channel common response remains an assumption until measured.

Stop-and-measure time includes travel, yaw turns, settling and sample windows. In the local physical mode, yaw rate and linear speed are bounded, movement is incremented rather than teleported, and an inflated footprint blocks proposed motion. Acceleration, pose uncertainty, SLAM, anemometer dynamics, body-frame apparent-wind conversion and rotor/wake disturbances are not represented. For the published ideal simulated survey these are scope limits, not newly discovered implementation defects. They become necessary integration tests when connecting a Go2/A2 or UAV.

The public controller environment strips `source` and `targetStatus`; estimator likelihoods come from a separately seeded simplified observation model rather than direct forward-field queries. The environment exposes a known map and prescribed mean-flow parameters, which are strong prior assumptions but disclosed. I found no direct source-coordinate or future-observation leak in the inspected mission interfaces. Gas maxima, mapped fitting nominations and source declarations remain distinct in the inspected asset controller; it returns `nativeAbstained: true` with a fitting candidate for reinspection. The curtain interface returns an upwind ray and `sourcePoint:null`, appropriately withholding range from one traverse.

## Evidence limits and rejected allegations

- **Rejected:** the SI atmosphere violates mass units or reflecting-ground normalization. Independent checks support those contracts at the tested settings.
- **Rejected:** the calibrated inlet test is presented as measured backpack calibration. Its documentation says the records are manufactured and use the same transfer-function family. Its result supports parameter recovery and integration consistency only.
- **Rejected:** the fitting survey omits all travel/settling time or teleports. The inspected engine advances bounded motion and includes dwell in mission time; ideal positioning remains a limitation.
- **Rejected:** a fitting flag is silently treated as a source declaration in the asset controller. The code explicitly abstains from source certification and the survey exporter asserts this contract.
- **Not established:** universal correctness of source confirmation, transport transfer to hardware, a realistic four-instrument payload, or research superiority over differently informed policies. This reviewer did not run those experiments.
- **Test-evidence caution:** `scripts/si-research-config.test.ts:41–48` calls the production half-space module and an import from `scripts/lib/halfspace-transport.ts`, but that latter file re-exports the same production class. Thus that particular test is a wiring-equivalence test, not independent numerical validation. Other finite-difference/PDE checks exist, and this review adds an independent quadrature/spatial-integration check. This is not an allegation that the field equations are wrong.

## Primary sensor source checked

LI-COR official LI-7810 product specification: https://www.licor.com/products/soil-flux/LI-7810 (web source `turn2search0`; root should open this URL before citing it). It gives 1 Hz measurement rate and a methane 10–90% response of at most 2 s in the standard configuration, consistent with the reference design's timing archetype. The specified standard flow is 250 sccm; the code correctly labels its separate 0.25 L/min input as **actual volumetric flow** rather than claiming an automatic sccm conversion. A physical setup must measure or correctly convert that flow. This check supports an archetype, not device-equivalence or calibration. No purchasing recommendation was made.

## Smallest useful next physical experiment

For the existing mapped-fitting task, measure each installed channel's clean-air/span/clean-air response with synchronized inlet reference concentration and actual flow. Fit a training pulse record and score a distinct pulse sequence before freezing timing. Then run blind paired missions on mapped fittings under a surveyed near-fitting release, no release, and an off-map neighbour/upwind interferer, logging inlet pose, wind and concentration on one clock. Use new release arrangements and wind conditions for evaluation, retain abstentions and timeouts, and report fitting nomination separately from verified source error. The experiment should test the current decision, not imply that a fixed recorded flight validates counterfactual autonomous navigation.
