import { HalfspaceTransport } from '../../repo/src/sim/halfspaceTransport'
import { LocalInletChannel } from '../../repo/src/sim/localInletSampling'
import { createDefaultConfig } from '../../repo/src/sim/config'
import { SimulationEngine } from '../../repo/src/sim/engine'
import { GSL_REFERENCE_DESIGN } from '../../repo/src/sim/physicalDesign'
import { withSIResearchDesign } from '../../repo/scripts/lib/si-research-config'

// Proposed review criteria, fixed before this script's first execution:
// exact delayed step error <1e-12; pulse spatial integral relative error <1e-5;
// continuous-release quadrature relative error <1e-5; gradient finite-difference
// relative error <1e-5; reject a robot start failing the environment footprint.
const start = performance.now()
const settings = { source: {x:0,y:0,z:0.025}, wind:{x:0.02,y:0}, diffusivity:0.001,
  sigma:0.15, rateKgPerSecond:2e-9, panelSeconds:2 }
const field = new HalfspaceTransport(settings)
const age=3, mass=1, spread=Math.sqrt(settings.sigma**2+2*settings.diffusivity*age)
const nx=80, ny=80, nz=80, hx=16*spread/nx, hy=16*spread/ny, hz=(settings.source.z+8*spread)/nz
let numericalMass=0
for(let iz=0;iz<nz;iz++) for(let iy=0;iy<ny;iy++) for(let ix=0;ix<nx;ix++) {
  const p={x:settings.wind.x*age-8*spread+(ix+0.5)*hx,y:-8*spread+(iy+0.5)*hy,z:(iz+0.5)*hz}
  numericalMass+=field.pulseAt(p,age,mass).concentration*hx*hy*hz
}
const pulseMass={expectedKg:1,numericalKg:numericalMass,relativeError:Math.abs(numericalMass-1)}
const point={x:0.4,y:0.08,z:0.05}, time=300, step=1e-5
const produced=field.evaluate(point,time)
const gradients=Object.fromEntries((['x','y','z'] as const).map(axis=>{
  const a=field.evaluate({...point,[axis]:point[axis]+step},time).concentration
  const b=field.evaluate({...point,[axis]:point[axis]-step},time).concentration
  const numerical=(a-b)/(2*step), analytic=produced.gradient[axis]
  return [axis,{analytic,numerical,relativeError:Math.abs(numerical-analytic)/Math.max(1e-30,Math.abs(analytic))}]
}))
// Independent Simpson integration over release age (not the implementation's
// four-node Gaussian panel quadrature).
const simpsonPanels=20000, da=time/simpsonPanels
let independent=0
for(let i=0;i<=simpsonPanels;i++) {
  const a=i*da, v=settings.sigma**2+2*settings.diffusivity*a
  const dx=point.x-settings.wind.x*a, dy=point.y-settings.wind.y*a
  const z1=point.z-settings.source.z,z2=point.z+settings.source.z
  const concentration=settings.rateKgPerSecond*Math.exp(-(dx*dx+dy*dy)/(2*v))
    *(Math.exp(-z1*z1/(2*v))+Math.exp(-z2*z2/(2*v)))/(2*Math.PI*v)**1.5
  independent+=concentration*(i===0||i===simpsonPanels?1:i%2?4:2)
}
independent*=da/3
const continuous={productionKgPerM3:produced.concentration,simpsonKgPerM3:independent,
  relativeError:Math.abs(produced.concentration-independent)/independent}
const base={...createDefaultConfig('surge-cast','open'),durationSeconds:5,checkpointSeconds:[5],
  windDirectionDegrees:90,windNoise:0,robotStartPositionOverride:{x:0.02,y:0.5}}
const config=withSIResearchDesign(base,{...GSL_REFERENCE_DESIGN,domainMetres:6,referenceWindMetresPerSecond:0.02})
let boundary:any
try {
  const engine=new SimulationEngine(config)
  const blocked=engine.environment.isBlocked(engine.scenario.robotStart)
  const frame=engine.runToCompletion()
  boundary={accepted:true,initialStartBlocked:blocked,initialPosition:engine.scenario.robotStart,
    finalPosition:frame.robot.position,pathLengthMetres:frame.metrics.pathLengthMeters,
    collisionAttempts:frame.metrics.collisionAttempts,completionReason:frame.completionReason}
} catch(e) { boundary={accepted:false,error:String(e)} }
const channelSettings={...config.localInletSampling!,riseTimeConstantSeconds:1.75,recoveryTimeConstantSeconds:3.5}
const channel=new LocalInletChannel(channelSettings),delay=channel.delay,tau=1.75,window=1
const primitive=(x:number)=>x<=0?0:x-tau*(1-Math.exp(-x/tau))
let channelError=0
for(let t=0;t<=25;t+=0.25){
  const observed=channel.update(t,t>=5?1:0),x=t-5-delay
  const exact=(primitive(x)-primitive(x-window))/window
  channelError=Math.max(channelError,Math.abs(observed-exact))
}
console.log(JSON.stringify({node:process.version,pulseMass,gradients,continuous,
  reflectingGroundGradientZ:field.evaluate({...point,z:0},time).gradient.z,
  exactChannelStepMaximumAbsoluteError:channelError,boundary,
  wallSeconds:(performance.now()-start)/1000},null,2))
