import { GridPlume } from '../../repo/src/sim/gridPlume'
import { createDefaultConfig } from '../../repo/src/sim/config'
import { createScenario } from '../../repo/src/sim/scenarios'

// A full-height impermeable wall blocks outflow; plume starts far from all
// outer boundaries. Constant prescribed wind, zero diffusion, no intermittency,
// negligible decay and deliberately low amplitude avoid clipping. Proposed
// criterion: integrated scalar mass follows initial mass plus injected mass
// to <1% at t=6 s; compare an otherwise identical unobstructed field.
const common={...createScenario('open',71,createDefaultConfig()),
  source:{x:0.25,y:0.5},baseWind:{x:0.065,y:0},turbulence:0,gustStrength:0,
  diffusivity:0,referenceDiffusivity:0,intermittency:0,obstacles:[]}
const t=6, dt=0.05
const outputs=[]
for(const resolution of [32,64,128])for(const wall of [false,true]){
  const s={...common,obstacles:wall?[{id:'wall',x:0.45,y:0,width:0.10,height:1}]:[]}
  const plume=new GridPlume(s,4,{resolution,stepSeconds:dt,decaySeconds:1e9,sourceRate:0.01})
  const initial=plume.totalMassAt(0)
  const firstIncrement=plume.totalMassAt(dt)-initial
  const expected=initial+firstIncrement*t/dt
  const observed=plume.totalMassAt(t)
  outputs.push({resolution,wall,timeSeconds:t,expectedMass:expected,observedMass:observed,
    relativeBalanceError:(observed-expected)/expected,maxConcentration:Math.max(...plume.gridAt(t).values)})
}
console.log(JSON.stringify({node:process.version,outputs},null,2))
