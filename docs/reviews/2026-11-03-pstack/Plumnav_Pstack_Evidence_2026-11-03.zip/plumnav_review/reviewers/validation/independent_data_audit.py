"""Independent Python audit of bundled raw data and reported measurements.

No PlumeNav production functions are imported. This verifies arithmetic,
selection, and record identities, not physical adequacy or adaptive navigation.
Usage: python3 independent_data_audit.py /path/to/Plumnav
"""
import bisect
import csv
import gzip
import hashlib
import io
import json
import math
from pathlib import Path
import re
import statistics
import sys

repo = Path(sys.argv[1]).resolve()
v = repo / 'validation'
out = {'snapshot': '3507527250400d25081f3793191084c9c3356a56', 'checks': {}, 'limitations': [
    'This independently recomputes raw-data selection and metrics, not autonomous navigation.',
    'Expected estimator endpoints are read from committed outputs; root separately reruns production replays.',
    'Publisher archive bytes were not re-downloaded during this bounded review.',
]}
checked = 0
for line in (v / 'SHA256SUMS').read_text().splitlines():
    digest, relative = line.split('  ', 1)
    assert hashlib.sha256((v / relative).read_bytes()).hexdigest() == digest, relative
    checked += 1
out['checks']['checksums'] = checked

def distance(lat1, lon1, lat2, lon2):
    a, b, dlat, dlon = map(math.radians, [lat1, lat2, lat2-lat1, lon2-lon1])
    h = math.sin(dlat/2)**2 + math.cos(a)*math.cos(b)*math.sin(dlon/2)**2
    return 2 * 6371008.8 * math.atan2(math.sqrt(h), math.sqrt(1-h))

def near(a, b, tolerance=1e-6):
    assert abs(a-b) <= tolerance, (a, b, abs(a-b))

blackpool = json.loads((v/'expected/blackpool.json').read_text())
black_rows = []
for expected in blackpool['results']:
    raw = json.loads(gzip.decompress((v/f'data/blackpool/{expected["survey"]}.json.gz').read_bytes()))
    rows = raw['rows']
    peak = max(rows, key=lambda r:r[3])
    assert len(rows) == expected['samples']
    for a,b in zip(peak[1:], [expected['peakLatitude'], expected['peakLongitude'], expected['peakPpm']]): near(a,b)
    truth = raw['truth']
    distances = [distance(r[1],r[2],truth['latitude'],truth['longitude']) for r in rows]
    near(min(distances),expected['closestSampleM'])
    near(distance(peak[1],peak[2],truth['latitude'],truth['longitude']),expected['peakErrorM'])
    black_rows.append({'survey':raw['survey'], 'samples':len(rows), 'peak_error_m':expected['peakErrorM']})
scores = [r['curtainScore'] for r in blackpool['results'] if r['curtainScore']]
out['checks']['blackpool'] = {'surveys':len(black_rows), 'samples':sum(x['samples'] for x in black_rows),
    'median_peak_error_m': statistics.median(x['peak_error_m'] for x in black_rows),
    'accepted_bearings':len(scores), 'abstentions':len(black_rows)-len(scores),
    'median_accepted_bearing_error_m':statistics.median(x['crosswindOffsetMetres'] for x in scores),
    'beats_track_midpoint':sum(x['crosswindOffsetMetres'] < x['trackMidpointLineErrorMetres'] for x in scores),
    'beats_peak_line':sum(x['crosswindOffsetMetres'] < x['peakLineErrorMetres'] for x in scores)}

matrix = json.loads((v/'expected/matrix.json').read_text())
all_flights = sorted(p for p in (v/'data/matrix').iterdir() if re.fullmatch(r'\d{3}_\d{2}',p.name))
labelled, excluded = [], []
for folder in all_flights:
    files = list(folder.glob('*CH4_v2.csv.gz'))
    assert len(files)==1
    text = gzip.decompress(files[0].read_bytes()).decode()
    comments = re.sub(r'\s', '', ''.join(l[1:] for l in text.splitlines() if l.startswith('#')))
    source = re.search(r'Locationofsourceis(\d+\.\d+),(\d+\.\d+)', comments, re.I)
    if not source:
        excluded.append(folder.name)
        continue
    ref = next(r for r in matrix['results'] if r['flight']==folder.name)
    window = re.search(r'from(\d\d:\d\d:\d\d)to(\d\d:\d\d:\d\d)UTC',comments,re.I)
    records = list(csv.DictReader(io.StringIO('\n'.join(l for l in text.splitlines() if not l.startswith('#'))),delimiter=';'))
    selected = [r for r in records if window[1] <= r['Time_UTC'] <= window[2]]
    assert all(r['Flag']=='o' for r in selected)
    assert len(selected)==ref['validReadings']
    assert len(records)-len(selected)==ref['outsideWindow']
    peak = max(selected,key=lambda r:float(r['CH4_spec_corr']))
    near(float(peak['CH4_spec_corr'])/1000,ref['peakSignalPpm'])
    near(float(peak['Latitude']),ref['peakLatitude'])
    near(float(peak['Longitude']),ref['peakLongitude'])
    src_lat,src_lon=map(float,source.groups())
    near(distance(src_lat,src_lon,float(peak['Latitude']),float(peak['Longitude'])),ref['sourceErrorMetres'])
    near(min(distance(src_lat,src_lon,float(r['Latitude']),float(r['Longitude'])) for r in selected),ref['closestTrackMetres'])
    labelled.append(ref)
assert sorted(excluded)==sorted(r['flight'] for r in matrix['excluded'])
out['checks']['matrix'] = {'scored':len(labelled), 'excluded':len(excluded),
    'valid_readings':sum(r['validReadings'] for r in labelled), 'outside_window':sum(r['outsideWindow'] for r in labelled),
    'median_peak_error_m':statistics.median(r['sourceErrorMetres'] for r in labelled),
    'accepted_bearings':sum(r['curtainScore'] is not None for r in labelled),
    'independent_release_coordinates':len({tuple(sorted(r['source'].items())) for r in labelled})}

epfl = json.loads((v/'expected/epfl.json').read_text())
for ref in epfl['results']:
    text = gzip.decompress((v/f'data/epfl/ex{ref["flight"]}/scan_1.csv.gz').read_bytes()).decode()
    scans=[]
    for raw in text.splitlines()[1:]:
        t,x,y,z,signal=map(float,raw.split(','))
        if not (3<=x<=9 and 1<=y<=3 and .7<=z<=.8 and 0<=signal<=1000): continue
        if scans and t==scans[-1][0]:continue
        scans.append((t,x,y,signal))
    times=[s[0] for s in scans]
    aligned=[]
    for t,x,y,signal in scans:
        if t<times[0]+2:continue
        j=bisect.bisect_right(times,t-2)-1
        a,b=scans[j],scans[min(j+1,len(scans)-1)]
        weight=0 if a[0]==b[0] else (t-2-a[0])/(b[0]-a[0])
        aligned.append((t-times[0],a[1]+weight*(b[1]-a[1]),a[2]+weight*(b[2]-a[2]),signal))
    bins=[s for i,s in enumerate(aligned) if i==0 or math.floor(s[0])!=math.floor(aligned[i-1][0])]
    assert len(aligned)==ref['readings'] and len(bins)==ref['binnedReadings']
    peak=max(bins,key=lambda s:s[3])
    near(peak[1],ref['alignedCoverage1Hz']['x'])
    near(peak[2],ref['alignedCoverage1Hz']['y'])
    assert sum(s[3]>ref['thresholdMv'] for s in bins)==ref['hits']
positive=[r for r in epfl['results'] if r['hits']>0]
out['checks']['epfl'] = {'search_flights':len(epfl['results']),'positive_flights':len(positive),
    'no_hit_flights':[r['flight'] for r in epfl['results'] if not r['hits']],
    'native_declarations':sum(r['infotaxisDeclared'] for r in epfl['results']),
    'median_endpoint_m':statistics.median(r['infotaxisEstimateErrorM'] for r in epfl['results']),
    'positive_median_endpoint_m':statistics.median(r['infotaxisEstimateErrorM'] for r in positive),
    'matched_peak_median_m':statistics.median(r['alignedCoverage1HzErrorM'] for r in epfl['results'])}
folds=list(csv.DictReader((v/'data/epfl/commissioning-sensitivity.csv').open()))
accepted=[r for r in folds if r['status']=='ready']
out['checks']['epfl_transfer']={'accepted_commissioning_records':len(accepted),'total':len(folds),
    'gas_positive_fold_medians_m':[float(r['gas_positive_infotaxis_median_error_m']) for r in accepted],
    'comment':'Folds reuse ten flights; they are not independent experiments.'}

epa=json.loads((v/'expected/epa.json').read_text())
rows=list(csv.DictReader((v/'data/epa/controlled-release.csv').open()))
for ref in epa['results']:
    samples=[r for r in rows if int(r['pass'])==ref['pass']]
    assert len(samples)==ref['readings']
    peak=max(samples,key=lambda r:float(r['methane_ppm']))
    assert int(peak['worksheet_row'])==ref['peakRow']
    near(float(peak['methane_ppm']),ref['peakPpm'])
    for phase in ref['phases']:
        selected=samples[phase['phase']::10]
        chosen=max(selected,key=lambda r:float(r['methane_ppm']))
        assert int(chosen['worksheet_row'])==phase['peakRow']
        near(float(chosen['methane_ppm']),phase['peakPpm'])
out['checks']['epa']={'passes':len(epa['results']),'records':len(rows),'thinning_offsets_verified':30,
    'largest_shift_m':[r['maximumShiftMetres'] for r in epa['results']], 'source_accuracy':'not assessable: release coordinates absent'}

missions=list(csv.DictReader((v/'synthetic/fitting-holdout/missions.csv').open()))
out['checks']['holdout_summary']={'missions':len(missions),
    'mapped_flags':sum(bool(r['flagged_fitting']) for r in missions if r['case'].startswith('mapped')),
    'mapped_cases':sum(r['case'].startswith('mapped') for r in missions),
    'neighbour_flags':sum(bool(r['flagged_fitting']) for r in missions if r['case'].startswith('neighbour')),
    'neighbour_cases':sum(r['case'].startswith('neighbour') for r in missions),
    'blank_flags':sum(bool(r['flagged_fitting']) for r in missions if r['case'].startswith('blank')),
    'blank_cases':sum(r['case'].startswith('blank') for r in missions),
    'strict_outcomes':sorted(set(r['strict_source_outcome'] for r in missions))}
print(json.dumps(out,indent=2))
