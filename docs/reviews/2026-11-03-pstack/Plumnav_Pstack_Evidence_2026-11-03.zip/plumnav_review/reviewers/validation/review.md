# Independent experimental-evidence review

Snapshot: `3507527250400d25081f3793191084c9c3356a56`, `validate/controlled-release`.
Comparison base supplied by lead: `452d285e3ca6c8cfd6209bfbfe035e7ce0496fe7`.
Mode: REVIEW_ONLY. No tracked source, tests, data, or expected results were changed.
Reviewer: `/root/validation_review`, inherited GPT-6 Astra Pro session model; no model override or different-family reviewer was selected. The model name is the session-provided identity; no independently queryable backend identifier was exposed.

## Verdict

The recent external-data package supports reproducible component replay and narrowly scoped physical-data source-estimation results. The inspected reporting distinguishes measured peaks, source estimates, bearings, and declarations and preserves poor results and rejected calibrations. I found no confirmed new arithmetic or provenance defect in the reviewed replay paths. That conclusion is bounded: the lead independently runs the production commands; this review independently checks raw records, selection, arithmetic, and claim scope. It does not establish hardware readiness or adaptive-navigation performance.

The main scientific problem is transfer, not a hidden success result. Five of ten EPFL commissioning records are rejected. Among the five accepted thresholds, one produces 3.595 m median held-out Infotaxis error, substantially worse than the paired 0.667 m peak baseline. The most favourable default result cannot be treated as an instrument-independent localisation guarantee. The published docs already disclose this.

## Scope and executed checks

Read `validation/README.md`, `validation/verify.mjs`, all four dataset source notes, EPFL commissioning-sensitivity table/report, `docs/real-flight-validation.md`, `docs/robot-field-replay.md`, `docs/outdoor-wind-bearings.md`, `docs/methane-field-matrix.md`, `docs/empirical-epa.md`, `docs/fitting-survey.md`, `docs/inlet-calibration.md`, `docs/field-records.md`, and the relevant replay/calibration/survey code and expected outputs. Principal code files:

- `scripts/robot-field-replay.ts` and `scripts/robot-field-sensitivity.mjs`.
- `scripts/blackpool-field-replay.ts`, `scripts/methane-field-matrix.ts`, `scripts/empirical-epa-replay.ts`.
- `scripts/lib/measured-peak.ts`, `scripts/lib/curtain-replay.ts`, `src/sim/curtainBearing.ts`.
- `scripts/field-sensor-calibration.ts`, its CLI, `scripts/analyze-field-record.ts`.
- `scripts/validate-fitting-survey.ts` and its committed holdout inputs/outputs.

Executed:

```sh
python3 reviewers/validation/independent_data_audit.py repo \
  > reviewers/validation/independent_data_audit.json
```

Run from the `plumnav_review` directory. Actual run wall time was approximately 0.625 s. The script imports no PlumeNav production functions. Its acceptance conditions were assertions defined before execution: all 74 declared digests match; independently selected peak identities and row counts agree; independently calculated geographic distances agree within 1e-6 m; EPFL two-second pose alignment and one-Hz selection reproduce peak positions and hit counts; all 30 EPA thinning offsets select the same raw row. The check completed with exit code 0.

| Independently checked record set | Result |
| --- | --- |
| Versioned file hashes | 74/74 match |
| Blackpool measurements | 22/22 maxima and source distances agree; 77,135 rows |
| MATRIX measurements | 8/8 selected-window maxima and distances agree; 4,436 in-window + 1,200 outside-window rows; all 10 metadata exclusions agree |
| EPFL search flights | 9/9 independently aligned/decimated peak positions and hit counts agree |
| EPA controlled release | 597 records, 3/3 full peaks, 30/30 thinned peaks agree |
| Holdout outcome-table accounting | 12 missions; mapped flags 2/2; neighbour flags 2/2; blank flags 0/2; strict source result always unresolved-abstention |

This script reads committed Infotaxis endpoint predictions; it does not independently implement Infotaxis. Its source-error medians therefore verify arithmetic and reporting. The lead's fresh production replays establish whether those endpoints reproduce.

## Confirmed defects

No new confirmed defect in the bounded external-evidence components reviewed. I do not label known limitations below as newly reproduced software failures.

## Scientific findings and their consequences

### High consequence: commissioning sensitivity prevents a broad transfer claim

**Status:** established from inspected code and evidence; raw-record alignment checked independently. Full ten-fold production replay is delegated to lead.

**Evidence:** `scripts/robot-field-replay.ts:106–152` freezes one baseline before evaluating other flights. `scripts/robot-field-sensitivity.mjs:19–36` records all ten choices, including rejected ones. `validation/data/epfl/commissioning-sensitivity.csv` and accompanying report lines 3–17 retain all outcomes.

The accepted thresholds are 212.4, 188.9, 205.1, 201.0 and 200.2 mV. Their gas-positive held-out Infotaxis error medians are respectively 0.421, 3.595, 0.477, 0.537 and 0.591 m. Five calibration choices fail. The default endpoint median across nine searches is 0.399 m, but one of these searches has no hits and produces the same 0.228 m endpoint error in the all-miss control. The software correctly withholds an encounter-supported estimate for that flight.

**Implication:** publish the default protocol with the full sensitivity range; do not present the default as an expected result on a new sensor. The ten folds recycle the same flights and do not provide ten independent laboratory validations.

**Smallest next experiment:** independently acquire clean-air reference sessions on a new day, freeze a predeclared commissioning rule, then run target-present and blank missions without selecting the reference after seeing source errors. Compare paired peak and Infotaxis endpoints and retain rejection/no-hit outcomes.

### High consequence: external flights do not validate PlumeNav steering or the four-inlet decision

**Status:** established by code inspection, not an alleged runtime defect.

`scripts/robot-field-replay.ts:72–103` explicitly ignores motion commands. `scripts/lib/measured-peak.ts:17–52` supplies recorded poses directly to the controller. `scripts/empirical-epa-replay.ts:66–87` does the same. No trajectory can reveal gas concentrations at alternative locations that a PlumeNav policy would have chosen. These are legitimate estimation replays, and current docs acknowledge the limit (`docs/real-flight-validation.md:3,20,45`; `docs/fitting-survey.md:59–61`).

The four-inlet fitting survey instead uses synthetic sensor traces and steady analytical transport. All 12 held-out fitting outcomes are classified as unresolved-abstention at the strict source level. Four fitting flags include two close off-map neighbours. This is a reinspection decision, not source confirmation.

**Smallest next experiment:** on the intended backpack, measure each channel's step response independently, then record synchronized four-inlet poses, gas, wind and station revisits for a mapped release, blank, upwind confounder and 0.15 m neighbour. Subsequently execute randomized paired controller missions, because fixed-path replay alone cannot test navigation.

### Moderate consequence: outdoor bearing evidence is conditional and does not dominate simple controls

**Status:** established from inspected outputs; raw maxima and distances independently verified.

UK results have 13 bearings/22 surveys and 9 abstentions. The accepted median perpendicular miss is 4.687 m. The method beats the matched wind line through the track midpoint on only 6/13 accepted surveys and the peak-based line on 10/13. Swiss results have 1 bearing/8 surveys; its 29.80 m perpendicular miss is worse than both controls. The combined output is 14 directional constraints, 16 abstentions, and zero two-dimensional source points.

`src/sim/curtainBearing.ts:44–92` returns `sourcePoint:null` by contract. `scripts/lib/curtain-replay.ts:20–41` correctly separates signed along-ray position, perpendicular error, and half-line error. `docs/outdoor-wind-bearings.md:9–16` reports denominators and the adverse comparator results.

**Implication:** claiming successful localisation for all outdoor surveys, interpreting the 4.69 m as two-dimensional position error, or asserting consistent superiority to midpoint search would exceed the evidence. No such claim was found in the current inspected docs.

**Next validation:** preserve the same gates on a genuinely new day/site, include blank traverses, and test two crossing geometries if source range is to be inferred. Calibrate coverage of any claimed uncertainty interval; measured plume width and wind spread alone are not position confidence intervals.

### Moderate consequence: calibration is manufactured parameter recovery

**Status:** established by code and disclosed documentation.

`scripts/field-sensor-calibration.ts:116–145` creates training and held-out traces with an independent RK4 integrator and distinct noise sequences. Both use the same transfer-function family as production. The fit recovers rise/recovery constants and is a meaningful code/inversion check, but cannot establish physical adequacy for an installed sensor, tubing, humidity or cross-channel differences. `docs/inlet-calibration.md:11–27` explicitly says no hardware observations enter the default example.

The equality guard at line 140 prevents accidentally supplying exactly identical arrays; it cannot certify independence of real experiments. Independent data acquisition and trace provenance remain the operator's responsibility.

## Provenance and access

Opened authoritative publisher pages for:

- ADApprox dataset: https://zenodo.org/records/17189796 (web reference `turn0view0`), confirms title, creator, publication date and archive MD5 `3a2480c66f179952aac35436fbc974d6`.
- Blackpool dataset: https://zenodo.org/records/3708518 (`turn0view1`), confirms physical UAV measurements, corrected data, stationary wind and archive MD5 `9825ff79de75931b5f848f27cc1ea34c`.
- MATRIX dataset: https://zenodo.org/records/6335359 (`turn0view2`), confirms QCLAS, AirCore, meteorology and archive MD5 `f792e7465772c3f0ba0546b5b92e9c29`.
- EPA catalogue: https://catalog.data.gov/dataset/methane-transect-dataset (`turn0view3`), confirms 10 Hz nominal acquisition, GPS/concentration/transsect records, three passes over one Durham release at 0.6 g/s and EPA terms.
- MATRIX primary article: https://amt.copernicus.org/articles/15/2177/2022/ (`turn1view3`), establishes the downwind emission-quantification purpose and instrument/RTK context. It reports 35 flights with 18 suitable for quantification; the PlumeNav bundle contains those 18 methane files, of which eight meet its explicit source-coordinate metadata rule. This is not evidence that PlumeNav suppressed 27 algorithm failures.

The local source notes explicitly describe data reuse terms and transformations. However, publisher JSON API licence endpoints were inaccessible through the web tool and the rendered Zenodo Rights sections omitted the licence text. I therefore verified publisher identity/archive metadata but did not independently reverify all three dataset licence labels during this pass. The upstream ADApprox preprocessing URLs were also inaccessible through the web fetch path. The repository provides exact commit URLs, making the stated two-second delay and upstream-strip choice traceable but not independently re-read here. Original complete publisher ZIPs were not re-downloaded. The independent audit verifies the bundled bytes against their repository manifest, not a fresh publisher download.

**Blackpool correction check requested by lead:** opened the 22 June 2020 corrigendum at https://amt.copernicus.org/articles/13/1467/2020/amt-13-1467-2020-corrigendum.pdf (web ref `turn7view0`). It replaces Figure 8 to correct vertical-axis flight labels and positions of several aggregate labels; the underlying flux results remain unchanged. It reports no correction to measured gas/GPS/wind or source coordinates. PlumeNav uses archived MATLAB observations and identifiers, not those plotted Figure 8 labels. No effect on the inspected peak/bearing replays is established by this correction.

The repository explicitly has no top-level software licence (`validation/README.md`). This is a reuse/packaging gap to resolve before inviting unrestricted external modification; it is not evidence of a computational failure or a defect in the included datasets' attribution.

## Claim-evidence classification

| Claim | Classification | Evidence and limit |
| --- | --- | --- |
| Bundled raw-data selection and reported peak/distance arithmetic are consistent | Supported within inspected records | Independent Python audit of every scored flight/pass |
| Default EPFL estimator can attain sub-metre endpoints on these recorded trajectories | Partly supported | 9 endpoints within 1 m, but no native declarations, one all-miss endpoint, strong calibration sensitivity |
| Calibration transfers reliably between commissioning records | Unsupported as a general claim | Only 5/10 accepted; accepted-fold median up to 3.595 m |
| Outdoor bearing estimator returns a complete source location | Unsupported | API always returns null sourcePoint; 14/30 bearings |
| Fitting policy resolves a source 0.15 m from a neighbour | Unsupported | Both close-neighbour cases flag the mapped fitting |
| Defaults calibrate an actual Birmingham backpack | Unsupported | Default data are manufactured; physical calibration instructions are provided |
| External datasets validate autonomous robot operation | Unsupported | Commands ignored and recorded trajectories supplied |
| The package conceals failed commissioning/search cases | Rejected allegation | Rejections, no-hit flights, abstentions, distant peaks and neighbour flags are explicit |

## Rejected allegations

1. **Source coordinates leak into EPFL estimation:** not supported. Source references load only after all predictions at `robot-field-replay.ts:157–170`; raw-data guard hashes ensure expected inputs. A known survey rectangle and measured tunnel wind are declared experimental priors.
2. **High outdoor errors prove a broken peak estimator:** rejected. Independent raw maxima agree exactly; downwind tracks cannot select a near-source point they never visited. Those high errors demonstrate the estimator's task limitation.
3. **Forty flights mean forty independent robot demonstrations:** rejected interpretation. It is one commissioning flight plus 39 scored recorded-flight replays from three studies; repeated flights share campaigns and conditions.
4. **No-hit Infotaxis proximity is gas-supported localisation:** rejected. The all-miss control reproduces it, and the returned encounter-supported estimate is null.
5. **Fitting flag is a hidden source declaration:** not supported. The runner throws if an inspection creates a native declaration (`validate-fitting-survey.ts:112–118`), and all holdout strict outcomes are unresolved-abstention.

## Readiness, bounded to this review

Reproducible component demonstration: supported by the data/arithmetic audit, subject to the lead's installation and runtime checks. Simulation study: usable for a narrowly specified fitting-screening experiment; shared steady-transport assumptions and a small correlated case panel remain. Externally validated research claim: supported only for the stated recorded-path estimator experiments, with transfer limitations. Deployment on a real Go2/A2: not established by the inspected evidence.
