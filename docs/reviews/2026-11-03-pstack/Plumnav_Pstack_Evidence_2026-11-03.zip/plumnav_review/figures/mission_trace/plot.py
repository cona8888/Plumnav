#!/usr/bin/env python3
"""Reproduce the two-panel Plumnav A-90 mission figure from bundled CSV files.
Requirements: Python 3, matplotlib. Run: python3 plot.py
All axes are physical quantities. SVG text is retained for editing in Inkscape.
"""
import csv
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch

HERE = Path(__file__).resolve().parent

def read(name):
    with (HERE / name).open(newline='') as f:
        return list(csv.DictReader(f))

readings = read('readings.csv')
stops = read('stops.csv')
geometry = read('geometry.csv')
summary = read('summary.csv')[0]
num = lambda row, key: float(row[key])
t = [num(r, 'time_s') for r in readings]
x = [num(r, 'x_m') for r in readings]
y = [num(r, 'y_m') for r in readings]
c = [num(r, 'methane_excess_ppm') for r in readings]
verification_start = num(summary, 'verification_start_s')
red = '#a51c30'
plt.rcParams.update({
    'font.family': 'sans-serif',
    'font.sans-serif': ['Liberation Sans', 'DejaVu Sans'],
    'font.size': 10,
    'axes.labelsize': 11,
    'axes.titlesize': 12,
    'xtick.labelsize': 10,
    'ytick.labelsize': 10,
    'axes.linewidth': 0.8,
    'svg.fonttype': 'none',
    'pdf.fonttype': 42,
    'ps.fonttype': 42,
    'savefig.facecolor': 'white',
})
fig, (ax, bx) = plt.subplots(1, 2, figsize=(13.2, 6.6), gridspec_kw={'width_ratios': [1, 1.32]})
fig.subplots_adjust(left=.065, right=.98, top=.80, bottom=.30, wspace=.24)
fig.suptitle('A mapped fitting flagged for reinspection', x=.065, ha='left', y=.98,
             fontsize=15, fontweight='bold')
fig.text(.065, .935, 'Fresh synthetic mission A-90  |  two survey passes, then an upwind and crosswind comparison',
         fontsize=10.5, color='.30')

# Recorded positions are one-second observations, not all physics integration ticks.
survey = [i for i, ti in enumerate(t) if ti <= verification_start]
verify = [i for i, ti in enumerate(t) if ti >= verification_start]
ax.plot([x[i] for i in survey], [y[i] for i in survey], color='.68', lw=2, zorder=2)
ax.plot([x[i] for i in verify], [y[i] for i in verify], color='.12', lw=1.2, zorder=3)
ax.plot(x[0], y[0], 'o', mfc='white', mec='black', ms=6, zorder=5)
ax.annotate('Start', (x[0], y[0]), xytext=(-8, -17), textcoords='offset points', ha='center')
for p in geometry:
    px, py = num(p, 'x_m'), num(p, 'y_m')
    role, label = p['role'], p['label']
    if role == 'fitting':
        ax.plot(px, py, 's', mfc='white', mec='black', ms=7, mew=1.2, zorder=6)
        off = {'A': (-10, -16), 'B': (-10, -15), 'C': (11, -15), 'D': (11, 4)}[label]
        ax.annotate(label, (px, py), xytext=off, textcoords='offset points',
                    ha='center', fontsize=11, fontweight='bold', zorder=7)
    elif role == 'control':
        ax.plot(px, py, 'o', mfc='white', mec='.15', ms=4.5, zorder=5)
        off = {'U':(-14, -11), 'L':(-13, 9), 'R':(-13, -11)}[label]
        ax.annotate(label, (px, py), xytext=off, textcoords='offset points', ha='center', fontsize=10)
    elif role == 'source':
        ax.plot(px, py, marker='x', color='black', ms=7, mew=1.3, zorder=8)
        ax.annotate('Hidden release: 5 cm from A\n(evaluation only)', (px,py), xytext=(2.20,1.12),
                    textcoords='data', ha='left', va='center', fontsize=9,
                    arrowprops={'arrowstyle':'-', 'lw':.75, 'color':'.25'},
                    bbox={'boxstyle':'round,pad=.2','fc':'white','ec':'none'}, zorder=9)
ax.annotate('', xy=(4.05,1.70), xytext=(3.27,1.70), arrowprops={'arrowstyle':'->','lw':1.1,'color':'black'})
ax.text(3.65,1.50, 'Wind: 0.02 m/s', ha='center', fontsize=9)
ax.set(xlim=(.65,4.55), ylim=(4.5,.9), xlabel='Map x (m; east positive)', ylabel='Map y (m; south positive)')
ax.set_aspect('equal', adjustable='box')
ax.set_xticks([1,2,3,4]); ax.set_yticks([1,2,3,4])
ax.set_title('(a) Recorded route and comparison locations', loc='left', pad=10)
ax.grid(lw=.5, color='.91', zorder=0)
for spine in ('top','right'):
    ax.spines[spine].set_visible(False)
# The route traverses each mapped fitting twice; directional arrows avoid false offset paths.
ax.annotate('', xy=(2,3.55),xytext=(2,3.05),arrowprops={'arrowstyle':'->','color':'.45','lw':1.3},zorder=4)
ax.annotate('', xy=(3.5,4),xytext=(3,4),arrowprops={'arrowstyle':'->','color':'.45','lw':1.3},zorder=4)
ax.annotate('', xy=(4,2.45),xytext=(4,2.95),arrowprops={'arrowstyle':'->','color':'.45','lw':1.3},zorder=4)
ax.legend(handles=[
    Line2D([0],[0],color='.68',lw=2,label='Two survey passes'),
    Line2D([0],[0],color='.12',lw=1.2,label='Wind comparison + return'),
    Line2D([0],[0],marker='s',mfc='white',mec='black',ls='',ms=6,label='Mapped fitting A–D'),
],loc='lower left',bbox_to_anchor=(0,1.10),ncol=2,frameon=False,fontsize=8.6,columnspacing=1.0)

# Shaded intervals come directly from controller visit logs. Dark slivers begin only
# after the configured settling duration; their height does not encode concentration.
for s in stops:
    lo, hi, settled = num(s,'arrival_s'), num(s,'departure_s'), num(s,'settled_from_s')
    bx.axvspan(lo,hi,color='.92',lw=0,zorder=0)
    bx.axvspan(settled,hi,color='.68',lw=0,zorder=1)
    mid=(lo+hi)/2
    bx.text(mid,.925,s['label'],ha='center',va='center',fontsize=8.5,
            fontweight='bold' if s['kind']=='verification' else 'normal',color='.25')
    bx.hlines(num(s,'median_excess_ppm'),settled,hi,color='black',lw=2,zorder=4)
bx.plot(t,c,color=red,lw=1.45,zorder=3)
decision=num(summary,'decision_s')
bx.axvline(decision,color='.15',ls=(0,(3,2)),lw=.9,zorder=2)
bx.annotate('Reinspection flag\n397.75 s', xy=(decision,.67), xytext=(355,.79),
            ha='center',va='bottom',fontsize=9,
            arrowprops={'arrowstyle':'->','lw':.8,'color':'.15'},
            bbox={'boxstyle':'round,pad=.2','fc':'white','ec':'none'},zorder=6)
bx.set(xlim=(0,408),ylim=(-.015,.96),xlabel='Elapsed mission time (s)',ylabel='Methane excess (ppm)')
bx.set_xticks([0,100,200,300,400]); bx.set_yticks([0,.2,.4,.6,.8])
bx.set_title('(b) Gas readings and settled sampling windows',loc='left',pad=10)
bx.grid(axis='y',color='.88',lw=.5,zorder=0)
for spine in ('top','right'):
    bx.spines[spine].set_visible(False)
bx.legend(handles=[
    Line2D([0],[0],color=red,lw=1.45,label='Four-inlet mean'),
    Patch(facecolor='.92',edgecolor='none',label='Dwell, including settling'),
    Patch(facecolor='.68',edgecolor='none',label='Settled sample window'),
    Line2D([0],[0],color='black',lw=2,label='Retained-sample median'),
],loc='lower left',bbox_to_anchor=(0,1.10),ncol=2,fontsize=8.6,frameon=False,columnspacing=1.1)

fig.text(.065,.190,'A1–D1 and A2–D2: first and second passes. U: upwind. L/R: left/right across the wind. A*: final return.',fontsize=9.2)
fig.text(.065,.145,'398 valid readings at 1 s intervals; logged path 19.58 m; decision 397.75 s; final simulation clock 398.00 s.',fontsize=9.2)
fig.text(.065,.100,'Outcome: A warrants reinspection. The source remains unresolved; its plotted position was used only for evaluation.',fontsize=10.3,fontweight='bold')
fig.text(.065,.055,'Synthetic SI half-space transport with manufactured-trace inlet calibration. This figure is not a real-robot or experimental validation result.',fontsize=9,color='.35')

for ext in ('svg','pdf','png'):
    fig.savefig(HERE / f'mission_trace.{ext}',dpi=240,metadata={'Creator':'Plumnav review figure'})
plt.close(fig)
